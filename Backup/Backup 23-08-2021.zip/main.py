from game_rpg import setup, player, items, interface, entity, enemies, battle
import json, time


Hero = player.Player("Player", "archer")
enemy = enemies.RandomEnemy()
setup.Player = Hero
Hero.luck = 10000
def axe():
    return items.get_("axe", 2, stats_r=True)
armor = items.get_("armor", 1)
#food = items.get_("food", 1)

if __name__ == '__main__':
    Hero.equip_items(axe(), "off_hand")
    enemy.equip_items(axe(), "off_hand")
    Battle = battle.Battle(Hero, enemy)
    Battle.run()