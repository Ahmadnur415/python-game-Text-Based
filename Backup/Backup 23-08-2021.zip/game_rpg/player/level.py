


def levelUp(self):
    if self.level < 60:
        self.level += 1
        self.exp -= self.max_exp
        self.max_exp = round((50 * self.level) + (128 * self.level / 4) + 174)
        self.pointlevel += 2
        