from .. import entity, setup as init


class Player(entity.Entity):
    def __init__(self, name, _class):
        if _class not in init.DATA_ENTITY["attribute"]["player.role"]:
            return
        super().__init__(name, **init.DATA_ENTITY["class"][_class]["statsistic"])
       
        self.__class = _class
       
        self.exp = 0
        self.max_exp = 100
        self.level = 1
        self.gold = 100
        self.silver = 10000
        self.__pointlevel = 0
        self.typeAttack = init.DATA_ENTITY["class"][_class]["typeAttack"]

        self.health = self.max_health
        self.mana = self.max_mana
        self.stamina = self.max_stamina
        

    @property
    def class_(self): return self.__class

    @property
    def pointlevel(self): return self.__pointlevel
    @pointlevel.setter
    def pointlevel(self, value): self.__pointlevel += (value if value <= 10 else 1)

