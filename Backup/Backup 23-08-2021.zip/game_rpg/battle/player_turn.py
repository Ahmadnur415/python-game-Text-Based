from .. import interface,setup


ATTACK = "attack"
USE_ITEMS = "use items"
RUN = "run"
TURN_COMMAND = [ATTACK, USE_ITEMS, RUN]


def command_Battle_player(battle):
    index = interface.get_input("1 - {len(TURN_COMMAND)} ")

    
    if TURN_COMMAND[int(index)] == ATTACK:
        ...
    if index == USE_ITEMS:
        ...
    if index == RUN:
        ...