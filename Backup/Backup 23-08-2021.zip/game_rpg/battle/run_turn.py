def run_turn(battle):
    battle.view_battle()
