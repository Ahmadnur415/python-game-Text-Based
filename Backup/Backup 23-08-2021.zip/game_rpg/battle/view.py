from .. import interface, setup


def view_battle(Battle):
    interface.line(d_left=2, d_rigth=2)
    interface.centerprint("Battle")
    interface.line(d_left=2, d_rigth=2)

    list_view = ["name", "damage", "health", "mana", "stamina", "class_"]
    for name in list_view:
        
        left = setup.DATA_GAME["_view"].get(name, name) + " : " + str(getattr(Battle.player, name, 0))
        rigth=str(getattr(Battle.enemy, name, 0)) + " : " + setup.DATA_GAME["_view"].get(name, name)

        if name in ("health", "mana", "stamina"):
            max_value_1 = getattr(Battle.player, "max_"+name, 0)
            max_value_2 = getattr(Battle.enemy, "max_"+name, 0)
            if max_value_1:
                left += " / " + str(max_value_1)
            if max_value_2:
                rigth =str(max_value_2) + " / " + rigth
        
        if name in ("damage"):
            left = setup.DATA_GAME["_view"].get("damage", "damage") + " : " + interface.list_line(getattr(Battle.player, "view_damage", [1, 5]), pemisah=" ~ ")
            rigth = interface.list_line(getattr(Battle.enemy, "view_damage", [1, 5]), pemisah=" ~ ") + " : " + setup.DATA_GAME["_view"].get("damage", "damage")

        interface.LeftRigthPrint(
            left=left,
            rigth=rigth,
            distance=2
            
        )   
    