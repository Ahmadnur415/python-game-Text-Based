from .. import until
from . import view, run, run_turn

class Battle:
    def __init__(self, player, enemy):
        until.set_multiple_attributes(
            self,
            player=player,
            enemy=enemy,
            first_turn=True
        )
    
    run = run.run
    view_battle = view.view_battle
    run_turn = run_turn.run_turn