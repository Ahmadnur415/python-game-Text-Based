def run(battle):

    while True:
        battle.run_turn()

        if battle.player.health <= 0:
            if battle.player.health < 0:
                battle.player.health = 0
            return # break

        if battle.enemy.health <= 0:
            return # win

        input(">>> ")
        
        battle.player.Attack(battle.enemy)
        battle.enemy.Attack(battle.player)