from . import data

global SETTING
global MESSAGES
global DATA_GAME
global Player
global shop


DATA_GAME = data.GAME
SETTING = DATA_GAME["setting"]
LANG = DATA_GAME["fileGame"].get("lang", data._load("lang.data"))
DATA_ENTITY = DATA_GAME["fileGame"].get("entity", data._load("entity.data"))
DATA_ITEMS = DATA_GAME["fileGame"].get("items", data._load_items())

# games
Player = None
shop = None


def MESSAGES(index):
    return LANG[SETTING["lang"]].get(index, LANG["en"].get(index, "???"))