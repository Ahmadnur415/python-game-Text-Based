from .. import interface, setup


def equip_items(self, items, location=None):
    
    if items.attribute.namespace != "EQUIPPABLE": # or items.attribute.location not in setup.DATA_ENTITY["attribute"]["equipment"]:        
        interface.print_(setup.MESSAGES("equipment.items_cant_use").format(item=items.name))
        return 

    if location not in items.attribute.location:
        location = None

    location_equipment: str = ""

    if type(items.attribute.location) == list and not location:
        if len(items.attribute.location) > 1:
            while True:
                print() # jeda 1 baris
                print(
                    setup.MESSAGES("equipment.choise_locate_items").format(
                        location=interface.list_line(items.attribute.location, number=True, replace=("_", " "))
                    )
                )
                # index = interface.get_input(f"[1 - {len(items.attribute.location)} | c]")
                index = interface.get_input(
                    setup.MESSAGES("input_messages.choise_index").format(index=f"1 - {len(items.attribute.location)}", other="C")
                )

                try:
                    if index == "c":
                        return
                    if int(index) > 0 and int(index) <= len(items.attribute.location):
                        location_equipment = items.attribute.location[int(index)-1]
                        break
                    
                except ValueError:
                    pass
                
        if len(items.attribute.location) == 1:
            location_equipment = items.attribute.location[0]
    else:
        location_equipment = items.attribute.location
        if location:
            location_equipment = location
    

    # == proses:
    # Over
    item_use = self.equipment[location_equipment]
    if item_use:
        interface.print_(
            setup.MESSAGES("equipment.item_already_equipped").format(
                item=item_use.name
            )
        )
        choise = interface.get_boolean_input()
        if not choise:
            return
        self.unequip_items(location_equipment)

    if items.attribute.use and type(items.attribute.location) == list:
        for locate in self.equipment.keys():
            if items == self.equipment.get(locate):
                self.unequip_items(locate)

    # equip items
    self.equipment[location_equipment] = items

    # add stats Items
    for names in setup.DATA_ITEMS["attribute"]["primary"]:
        value = getattr(items.attribute, names, 0)
        ...


    items.attribute.use = True

def unequip_items(self, locate_items):
    items_to_unequip = self.equipment.get(locate_items)

    if not items_to_unequip:
        return
    
    self.equipment[locate_items] = None
    items_to_unequip.attribute.use = False



    # for stats in setup.DATA_ITEMS["attribute"]["subs_stats"]:
    #     name_stats = stats['name']
    # value_stats = getattr(items_to_unequip.sub_stats, name_stats, 0)
    #     setattr(
    #         self,
    #         name_stats,
    #         getattr(self, name_stats) - value_stats
    #     )

