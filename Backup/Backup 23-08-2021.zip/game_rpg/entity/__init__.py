from ..setup import DATA_ENTITY as DATA
from .. import until
from . import (other_property, equipment, inventory, view, attack)

class Entity:
    def __init__(self, name="Entity",  **stats):
        base = DATA["stats"]

        # get primary stats    
        [setattr(self, name, 0) for name in base["primary"]]
        
        # get other stats 
        for _, nameStats in base["_other"].items():
            [setattr(self, name, 0) for name in nameStats]

        until.add_multiple_attributes(self, **stats)

        self.__name = name
        self.displayName = "Entity"
        self.equipment = {}
        for _, names in DATA["attribute"]["equipment"].items():
            self.equipment.update(dict.fromkeys(names))


        self.inventory = []

    @property
    def name(self):
        return self.__name
    
    # statsistic entity
    max_health = other_property.max_health
    max_mana = other_property.max_mana
    max_stamina = other_property.max_stamina

    # crit
    critical_change = other_property.critical_change
    critical_hit = other_property.critical_hit
    
    # damage
    view_damage = other_property.view_damage
    damage_reduce = other_property.damage_reduce
    true_damage = other_property.true_damage
    bonus_damage = other_property.bonus_damage
    damage = other_property.damage

    # inventory and equipment
    equip_items = equipment.equip_items
    unequip_items = equipment.unequip_items
    append_inventory = inventory.append_inventory
    
    # view
    view_stats = view.view_stats
    view_inventory = view.view_inventory
    view_equipment = view.view_equipment

    # attack
    Attack = attack.attack

