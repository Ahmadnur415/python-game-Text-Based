from .. import interface, setup

def view_equipment(self):
    print("== EQUIPMENT ==".center(50))
    for loacte_equip, items_equip in self.equipment.items():
        name = "-" if not items_equip else items_equip.name
        loacte_equip = loacte_equip.replace("_", " ").capitalize().strip()
        print(f" {loacte_equip:<15} : {name}")

def view_inventory(self):
    interface.centerprint("== Inventory ==")
    if not self.inventory:
        interface.centerprint(setup.MESSAGES("inventory.no_have_items"))
        return
    line_ = " {no:<6}{name:<19}{quality:<15}{type_:<9}"
    print("-"*50)
    print(line_.format(no="NO", name="NAME", quality="QUALITY", type_="TYPE"))
    print("-"*50)
    for i, items in enumerate(self.inventory):
        name = items.name
        if items.attribute.namespace == "EQUIPPABLE":
            name += ("  [E]" if items.attribute.use else "")
        else:
            name += (f"  {items.amount}x" if items.amount > 1 else "")
        print(
            line_.format(no=i+1, name=name, quality=items.quality, type_=items.typeItems)
        )


def view_stats(self):   
    distance = 1
    EXP_PER = round((100 * self.exp) / self.max_exp, 1)
    if self.level < 60:
        exp = str(self.exp) + "/" + str(self.max_exp) + " | " + str(EXP_PER) + "%"
    else:
        exp = "0 / 0 | 0% (max)"

    # Show
    print(f"{self.name} : ")
    interface.leftprint(">>> Primal Stats", distance=distance)
    interface.printData(
        {setup.DATA_GAME["_view"].get(names, names): getattr(self, names, 0) for names in setup.DATA_ENTITY["stats"]["primary"]},
        distance=distance
    )

    interface.leftprint(">>> Subs Stats", distance=distance)
    interface.printData(
        {
            "Health": self.max_health, "Mana": self.max_mana, "Stamina": self.max_stamina, "Luck": self.luck,
            "C.Change": str(self.critical_change) + "%",  "C.Hit": self.critical_hit, "Growth Hp": self.growth_hp, "Growth Mp": self.growth_mp
        }, distance=distance
    )

    interface.leftprint(">>> Defense", distance)
    interface.printData(
        {setup.DATA_GAME["_view"].get(names, names): getattr(self, names, 0) for names in setup.DATA_ENTITY["stats"]["_other"].get("defense", "NONE")},
        distance=distance
    )

    # ========
    interface.leftprint(">>> Other", distance)
    interface.printData(distance=distance, Gold=self.gold, Silver=self.silver, Level=self.level, EXP=exp ,Role=self.class_)