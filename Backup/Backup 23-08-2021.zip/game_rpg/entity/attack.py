import math

def attack(attacker, enemy, attack_use=None):
    true_damage = 0

    # true damage 
    if not attack_use:
        # set default
        defense = enemy.defense

        # pengurangan enemy defense 
        enemy.defense -= int(enemy.defense * attacker.armor_penetration / 100)

        # attack
        true_damage = attacker.true_damage - math.floor(enemy.damage_reduce * attacker.true_damage / 100)
        enemy.health -= true_damage
        print(f"{attacker.name} attack {enemy.name} by damage {true_damage}")

        # mengembalikan defense 
        enemy.defense = defense

    # bonus damage
    if attacker.bonus_damage:
        for bonus_damage in attacker.bonus_damage:
            damage = resolve_damage(math.floor(bonus_damage["value"]))
            enemy.health -= damage
            print(f"bonus damage {damage} {bonus_damage['name'].replace('_', ' ').capitalize()}")


    # enemy pasive [lifesteel]

    if enemy.health < 0:
        enemy.health = 0

def resolve_damage(damage: int):
    if damage < 0:
        damage = 1
    return damage