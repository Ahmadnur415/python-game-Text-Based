import math, random
from ..items.create import Items as ITEMS
from ..setup import DATA_GAME as DATA, DATA_ENTITY
from ..until import _random_value_list

CON = 0
STR = 0
ARC = 0
PERC = 0
MGC = 0
WILL = 0
LUCK = 0
LV = 0
G_HP = 0
G_MP = 0
DEF = 0
EVE = 0
RES = 0


def init(entity): 
    global CON, STR, ARC, PERC, MGC, WILL, LUCK, WILL, LUCK, LV, G_HP, G_MP, DEF, EVE, RES
    CON = entity.constitution
    STR = entity.strength

    ARC = entity.archery
    PERC = entity.perception

    MGC = entity.magic
    WILL = entity.will

    LUCK = entity.luck
    LV = entity.level
    G_HP = entity.growth_hp
    G_MP = entity.growth_mp

    DEF = entity.defense
    EVE = entity.evasion
    RES = entity.resistance


@property
def damage_reduce(entity):
    # point defense -> Random
    # init
    init(entity)

    bonus_Pd = 0
    for name in DATA_ENTITY["attribute"]["equipment"]["armor"]:
        names = entity.equipment.get(name, None)
        if names:
            bonus_Pd += names.attribute.defense

    total_Pd = math.floor((DEF + bonus_Pd + (CON / 3) + (RES / 4)) / 3)
    pd = random.randint( math.floor(total_Pd / 21 + 1), math.floor(total_Pd / (total_Pd / 12 + 2) + 5) )
    return math.floor(pd + (100 - 10000 / (100 + DEF)))


@property
def magic_reduce(entity):
    ...


@property
def max_health(entity):
    init(entity)
    HP = G_HP * ((CON * 70 + WILL * 5 + STR) / 21 + ((50 - (0.121 * LV)) * LV)) / 100
    return math.floor(HP + 50)


@property
def max_mana(entity):
    init(entity)
    MP = G_MP * ((25 * WILL + 2 * MGC) / 10 + 5 * LV / 2) / 100
    return math.floor(MP + 20)


@property
def max_stamina(entity):
    init(entity)
    MP = (15 * ARC + 30 * PERC + 26 * STR + 125 * LV) / 60
    return math.floor(MP + 12)


@property
def critical_change(entity):
    # init
    init(entity)


    bonus = 0
    # equipment bonus
    for items in entity.equipment.values():
        if isinstance(items, ITEMS):
            values = items.sub_stats.get("critical_change", {})
            bonus += values.get("value", 0)

    crit = LUCK * ((PERC / 4) + (STR * 2 + ARC + MGC) / 30 + (0.3 * LV)) / 120
    return round(crit + bonus, 2)


@property
def critical_hit(entity):
    # init 
    init(entity)
    
    bonus = 0
    # equipment bonus
    for items in entity.equipment.values():
        if isinstance(items, ITEMS):
            values = items.sub_stats.get("critical_hit", {})
            bonus += values.get("value", 0)


    dmg = (4 * STR + 4 * ARC + 4 * MGC + 3 * PERC + 2 * LV + 2 * CON) / 5
    return round(dmg + 20 + bonus, 2)


@property
def view_damage(entity) -> (list):
    # init
    init(entity)

    # proses
    bonus = [0, 0]
    for name in DATA_ENTITY["attribute"]["equipment"]["weapons"]:
        names = entity.equipment.get(name, None)
        if names:
            # TODO : dev
            multipler = getattr(entity, names.attribute.type_attack, 4) / 4
            # print(multipler)

            bonus = [a + math.floor(b * multipler) for a, b in zip(bonus, names.attribute.damage)]
    
    # return damage
    damage = [1 + bonus[0], 2 + bonus[1]]
    if bonus == [0, 0]:
        multipler = getattr(entity, getattr(entity, "typeAttack", "strength"), 1) / 4 
        damage = [math.floor(1 * multipler), math.floor(5 * multipler)]

    return damage


@property
def bonus_damage(entity):
    init(entity)
    bonus = []

    for items in entity.equipment.values():
        if items:
            value = items.multiplerStats(entity, items.GetSubStatsDamage())
            if value:
                bonus += value

    return bonus

@property
def true_damage(entity):
    init(entity)
    return _random_value_list(entity.view_damage)

@property
def damage(entity):
    init(entity)
    return 0                    


def lifesteel(entity, value, multipler):
    entity.health += (value * multipler / 100)


# def bonus_statsistic(entity, get_: str):
#     bonus = 0
#     for items in entity.equipment.values():
#         if isinstance(items, ITEMS):
#             stats = items.sub_stats.get(get_, None)
#             value = stats.get("value", 0)
#             multiplier = stats.get("multiplier", "").split(".")
#             category = stats.get("category", None)
#             if stats:
#                 if isinstance(multiplier, list) and len(multiplier) == 2:
#                     v_multi = 1
#                     if multiplier[0] == "items":
#                         if multiplier[1] == "quality":
#                             v_multi = DATA["quality"][items.quality].get("multiplier", 1)
#                     if multiplier[0] == "player":
#                         v_multi = getattr(entity, multiplier[1], 1)
#                     value *= v_multi

#             if category == "percent":
#                 bonus += round(value, 2)
#             else:
#                 bonus += int(value)

#     return bonus
            

