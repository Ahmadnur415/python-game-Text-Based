# inventory player
def append_inventory(player, item, *args):
    item = [item] + list(args)
    for items in item:
        if not player.inventory or items.typeItems in ("weapons", "armor"):
            player.inventory.append(items)
        elif items.typeItems in ("food", "potions"):
            for aa in player.inventory:
                # items bila ada yang sama
                if aa.typeItems == items.typeItems and aa.identify == items.identify:
                    aa.amount += items.amount
                    break
            else:
                player.inventory.append(items)
    

