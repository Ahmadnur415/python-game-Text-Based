from .enemy import Enemy
from .setup import Player, SETTING, DATA_ENTITY
import random


def RandomEnemy():
    return ENEMY("enemy", random.choice(list(DATA_ENTITY["class"])), 1 if not Player else Player.level)


def ENEMY(name, _class, level):
    lv = level
    difficulty = {"easy": -1, "normal": 0, "hard": 1}  
    if lv <= 2:
        lv = 1
    elif lv > 2 and lv < 6:
        lv = random.randint(2, 6)
    elif lv >= 6 and lv <= 59:
        i = difficulty[SETTING.get("difficulty", "normal")]

        lv = random.randint(lv - (4 - i), lv + i)
    else:
        lv = random.randint(55, 60)
    
    return Enemy(name, _class, lv)