import os
import json

def _load(filename):
    data = json.load(
            open(
                os.path.dirname(
                    os.path.realpath(__file__)
                    ) + "\\" +  filename + ".json"
                )
            )
    return data

     

def _load_items() -> (dict):
    base = _load("items.data")
    dirpath = "./item/" # lokasi dari item
    f_file = ".json" # sementara
    error = 0    
    # load items dari dir "item"
    for name_items, file_items in base["listitems"].items():
        if (file_items + f_file) in os.listdir(dirpath):
                _file = dirpath + file_items + f_file
                
                base["items"][name_items] = json.load(open(_file))
                
        else:
            print(f"Warning[{error}]: file {file_items} not found")
            error += 1
    
    return base


def load_message(lang:str = "en"):
    messages = _load("lang.data")

    if lang not in messages: 
        lang = "en"
    return messages[lang]


def _init():
    
    core = _load("game.data")
    filegame = {}
    for name, nfile in core["fileGame"].items():
        # print("load:", nfile)
        filegame[name] = _load(nfile)
        if name == "items":
            filegame[name] = _load_items()
    core["fileGame"] = filegame
    return core


GAME = _init()
