from .. import until, setup
from . import view, subsStats


class Items:
    def __init__(
            self,
            name: str,                      # name Items
            quality: str,                   # quality dari items
            typeItems: str,                 # type (food, potion, armor, weapons)
            identify: int,                  # idenfiy
            attribute: object,              # attribute EQUIPPABLE atau CONSUMABLE
            amount: int = 1,                # jumlah items
            price: dict = None,             # harga yang akan dijual
            sub_stats: object = None,       # sub_stats di pakai di attribute EQUIPPABLE
    ):  
        # set attributes dari class items
        until.set_multiple_attributes( 
            self,
            name=name,
            quality=quality,
            typeItems=typeItems,
            identify=identify,
            attribute=attribute,
            amount=amount,
            price=price,
            sub_stats=sub_stats
        )

    view_stats = view.view_stats
    
    GetSubStatByType = subsStats.GetSubStatByType
    GetSubStatsDamage = subsStats.GetSubStatsDamage
    GetSubStatsRecover = subsStats.GetSubStatsRecover
    GetSubStatsBonus = subsStats.GetSubStatsBonus
    GetSubStatsLifesteel = subsStats.GetSubStatsLifesteel

    multiplerStats = subsStats.multiplerStats

class EQUIPPABLE:
    def __init__(self, location, user, pasive=None, type_attack=None, **stats):
        self.__namespace = "EQUIPPABLE"                     # namespace untuk membedakan EQUIPPABLE dan CONSUMABLE
        self.use = False                                    # bila player memakai item akan nerubah menjadi True
        self.location = location                            # lokasi untuk dipakai
        self.pasive = pasive                                # pasive berbentuk object
        self.user = user
        self.type_attack = type_attack
        until.set_multiple_attributes(self, **stats)        # menambahkan stats

    @property
    def namespace(self):
        return self.__namespace

class CONSUMABLE:
    def __init__(self, type_, stats):
        self.__namespace = "CONSUMABLE"                     # namespace untuk membedakan EQUIPPABLE dan CONSUMABLE
        self.type_ = type_                                  # recover, increase
        self.stats = stats                                  # stats berupa Dict                               # pasive berbentuk object

    @property
    def namespace(self):
        return self.__namespace



change_get_stats_special = {
    "common": 3,
    "uncommon": 7,
    "rare": 15,
    "epic": 20,
    "legendary": 25,
    "special": 30
}