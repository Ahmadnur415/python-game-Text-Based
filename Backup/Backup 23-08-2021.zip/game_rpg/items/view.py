from .. import interface, setup


def view_stats(items):
    # interface.line()
    interface.centerprint(items.name)
    interface.line()

    base_stats = {
        "quality": items.quality, "price": str(items.price["value"]) + " " + items.price["type"].capitalize(),
        "type": items.typeItems.capitalize()
    }


    if items.attribute.namespace == "EQUIPPABLE":
        base_stats.update({"using": items.attribute.use})
        interface.printData(base_stats, distance=1)
        view_EQUIPPABLE(items)
    if items.attribute.namespace == "CONSUMABLE":
        base_stats.update({"amount": items.amount})
        interface.printData(base_stats, distance=1)
        view_CONSUMABLE(items)

def view_EQUIPPABLE(items):
    # weapons : (1 ~ 2 DMG, A.pen 10%)
    # armor : evesion +30  defense +30
    _view = setup.DATA_GAME["_view"]
    distance = 1

    if items.typeItems == 'weapons':
        DMG =  interface.list_line(getattr(items.attribute, "damage", [0, 0]), number=False, pemisah=" ~ ") + " Damage"
        APEN = str(getattr(items.attribute, "armor_penetration", 0)) + "% armor penetration "
        interface.leftprint("weapons attribute (" + DMG + ", " + APEN + ")", distance=distance)

    for name in setup.DATA_ITEMS["attribute"]["primary"]:
        if name not in ("damage", "armor_penetration"):
            value = getattr(items.attribute, name, 0)
            if value != 0:
                interface.printData({_view.get(name, name): f"{value:+}"}, one_line=True, mark=False, distance=distance)
    # sub stats
    show_line = True
    for key, stats in items.sub_stats.items():
        # line
        if show_line:
            interface.line(d_left=distance, d_rigth=1)
            show_line = False

        # print(key, stats)
        value = stats.get("value", 0)
        
        category = stats.get("category", None) 
        multiplier = stats.get("multiplier", None)
        TYPE = stats.get("type", None)
        names = _view.get(key, key)

        if category:
            if category == "percent":
                value = f"{value:+}%"

        if multiplier:
            value = str(value) + " by " + interface.list_line(multiplier.replace("_", " ").split("."), pemisah=" ")

        if TYPE:
            if TYPE == "damage":
                names = "Bonus " + names

        interface.printData(
            {names: f"{value:+}" if isinstance(value, int) else value},
            one_line=True, mark=False, distance=distance
        )



def view_CONSUMABLE(items):
    ...