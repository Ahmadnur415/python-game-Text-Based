from .create import *
from . import generate
from ..setup import DATA_ITEMS


def get_(class_, index: int=1, quality: int=None,  name: str=None, amount: int=1, att_r=False, stats_r=False):
    if class_ in DATA_ITEMS["listitems"]: 
        typeItems = DATA_ITEMS["listitems"][class_].split(".")[-1]
        if typeItems in ("food", "potions"):
            return generate.get_items_CONSUMABLE(class_=class_, name=name, amount=amount, index=index)
        if typeItems in ("armor", "weapons"):
            return generate.get_items_EQUIPPABLE(class_=class_, quality=quality, index=index, att_r=att_r, stast_r=stats_r)
    
    return print("warring[2]: error")

