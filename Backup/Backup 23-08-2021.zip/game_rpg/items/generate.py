from .. import until, setup, player
from . import create
import random

def get_items_CONSUMABLE(class_, name=None, amount=1, index=0):
    gPlayer = setup.Player # get Player


    
    listItems = setup.DATA_ITEMS["items"]

    # baseItems
    baseItems = listItems[class_]

    # Warning
    if index != "random" and isinstance(index, str):                        # cek index samadengan str dan buka "random"
        return print("Warning[0]: tidak bisa mendapatkan items")

    # get random index items
    index = random.randint(0, len(baseItems["list"]-1)) if index == "random" else index - 1

    # Warning
    if index < 0 or index >= len(baseItems["list"]):                    # index out of range       
        return print("Warning[1]: tidak bisa mendapatkan items")

    if name not in baseItems["item"] or not name:                       # get items menggunakan index dan nama tidak terdaftar di DATAITEMS["item"]
        index_items = baseItems["list"][index]                          # index_items = list["item.apple", "item.potion"]   
        items = baseItems["item"][index_items.split(".")[-1]]
    else:
        items = baseItems["item"][name]                                 # get items using name
    
    return create.Items(
        name=items["name"],
        quality=items["quality"],
        typeItems=baseItems["type_items"],
        identify=items["id"],
        price=items["price"],
        amount=amount,
        attribute=create.CONSUMABLE(
            type_=items["type"],
            stats=items["stats"]
        )
    )



def get_items_EQUIPPABLE(class_, index, att_r=False, stast_r=False, quality=None):    
    gPlayer = setup.Player
    pLuck = 1 + random.random()
    if isinstance(gPlayer, player.Player):
        pLuck = (gPlayer.luck / 100) + pLuck


    if class_ not in setup.DATA_ITEMS["items"]:
        print("debug 0")
        return
    
    class_items = setup.DATA_ITEMS["items"][class_]
    type_items = class_items["type_items"]
    
    # index items
    index_items = (index - 1  if index != "random" else random.randint(0, len(class_items["listitems"]) - 1))

    # get items in class items: dict 
    # names_items = class_items["list"][index_items].split(".")
    items = dictgetattr(class_items, class_items["listitems"][index_items])

    if not items:
        print("debug 2")
        return 

    # cek bila items menggunakan index
    if quality:
        if (quality in setup.DATA_GAME["quality"]) and (quality in class_items["quality"]) and (index != "random"):
            if len(class_items["quality"][quality]) < 1 or index < 0 or index >= len(class_items["quality"][quality]):
                print("debug 3")
                return
            else:
                # get items from quality
                items = dictgetattr(class_items, class_items["quality"][quality][index_items])
            if not items:
                print("debug 4")
                return 
        else:
            print(f"warring: Get items quality {quality} Error")
    
    if stast_r:
        sub_stats = get_substats(items)
    else:
        sub_stats = items.get("sub_stats", {})

    if att_r:
        bonus_stats = {}
        multiplier = setup.DATA_GAME["quality"][items["quality"]]["multiplier"] + pLuck
        for names in setup.DATA_ITEMS["attribute"]["primary"]:
            value = items.get(names, (until._generate_random_value(10) * multiplier) if names not in ('damage') else [2 * multiplier, 12 * multiplier])

            if isinstance(value, list):
                v_max = int(until._generate_random_value(max(value)) * (multiplier - 0.5))
                v_min = int(until._generate_random_value(min(value)) * (multiplier - 1))
                value = sorted([v_min, v_max])
            else:
                value = int(until._generate_random_value(value) * random.uniform(1, 5))
                if names == "armor_penetration" and value > 100:
                    value = until._generate_random_value(value)

            bonus_stats[names] = value  
            if isinstance(items.get(names, None), (list, int)):
                items[names] = value

        bonus = until.resolve_random_condition([(True, 15 + int(2 * multiplier)), (False, 85 - int(2 * multiplier))])
        if bonus:
            stats = random.choice(list(bonus_stats))
            items[stats] = bonus_stats[stats]

    # get harga
    # price = items.get("price", {"value": 5, "type": "gold", "max_discont": 5})
    # if att_r or stast_r:
    #     multiplier = setup.DATA_GAME["quality"][items["quality"]]["multiplier"]
    #     # 1 gold == 100 silver
    #     # setiap 1 luck berkurang ((multipler + 0.25) * player.luck / 100 silver) - multipler * gold
    #     # convet to silver
    #     if price["type"] == "gold":
    #         price["value"] *= 100
    #         price["type"] = "silver"
        
    #     count_att = len(sub_stats) + len([items.get(key, 0) for key in setup.DATA_ITEMS["attribute"]["primary"]])
    #     count_s = 0
    #     for i in setup.DATA_ITEMS["attribute"]["primary"]:
    #         j = items.get(i, 0)
    #         print(j)
    #         count_s += (sum(j) if isinstance(j, list) else j)
    #     print(count_s )

    #     # random discont
    #     price["max_discont"] = 20 + (2 * pLuck)
    #     price["value"] = int(price["value"] - ((pLuck * 25) / multiplier))

    return create.Items(    
        name=items["name"],
        quality = items["quality"],
        typeItems=type_items,
        identify=items["id"],
        attribute=create.EQUIPPABLE(
            location=class_items["slot"],
            user=class_items["user"],
            type_attack=items.get("type_attack", class_items.get("type_attack", None)),
            **{key: items.get(key, 0) for key in setup.DATA_ITEMS["attribute"]["primary"]}

        ),
        price=items["price"],
        sub_stats=sub_stats
    )

def dictgetattr(obj: dict, key: str):
    names = key.split(".")
    get = obj
    for name in names:
        try:
            get = get[name]
        except KeyError as e:
            print(e)
            return False
    return get



def get_substats(items):
    gPlayer = setup.Player
    sub_stats = items.get("sub_stats", {})
    change = setup.DATA_GAME["quality"][items["quality"]]["change"]
    luck = 0

    if isinstance(gPlayer, player.Player):
        luck = gPlayer.luck
        change = change + (5 * luck / 100)   
        if change > 100:
            change = random.randint(75, 99)

    change_special = until.resolve_random_condition([(False, 100 - change),(True, change)])
    chnage_normal = until.resolve_index_condition({"common": 0, "uncommon": 1, "rare": 2, "epic": 2, "legendary": 3, "special": 3}, index=items["quality"])
    bonus = until.resolve_random_condition([
        (0, 83 - int(2 * luck / 100)),
        (1, 15 + int(1.75 * luck / 100)),
        (2, 3 + int(0.25 * luck / 100))
    ])

    def foo(data: dict):
        names = random.choice(list(data))
        while names in sub_stats:
            names = random.choice(list(data))
        stats = data[names]
        if isinstance(stats["value"], list):
            stats["value"] = until._random_value_list(stats['value'])
            if isinstance(stats["value"], float):
                stats["value"] = round(stats["value"], 2)

        return {names : stats}

    # get special stats
    if change_special:
        count = 1 + bonus
        for _ in range(count):
            sub_stats.update(foo(setup.DATA_ITEMS["attribute"]["special"]))
            
    # get normal stats
    count = chnage_normal + bonus
    for _ in range(count):
        sub_stats.update(foo(setup.DATA_ITEMS["attribute"]["_other"]))


    return sub_stats