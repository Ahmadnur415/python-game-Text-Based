from ..setup import DATA_GAME as DATA


def GetSubStatByType(items, _type):
    value = []
    for names, values in items.sub_stats.items():
        if values.get("type", None) == _type:
            values["name"] = names
            value.append(values)
    return value


def GetSubStatsDamage(items):
    return GetSubStatByType(items, "damage")

def GetSubStatsRecover(items):
    return GetSubStatByType(items, "recover")

def GetSubStatsBonus(items):
    return GetSubStatByType(items, "bonus")

def GetSubStatsLifesteel(items):
    return GetSubStatByType(items, "lifesteel")

def _solved_multiplerStats(items, player, stats):
    if not stats:
        return 
    multiplier = stats.get("multiplier", None)
    value_multi = 1
    value = stats.get("value", 1)
    category = stats.get("category", "normal")
    _type = stats.get("type", None)

    if multiplier:
        by_, multiplier = multiplier.split(".")
        if by_ == "player":
            value_multi = getattr(player, multiplier, 1)
        if by_ == "items":
            value_multi = getattr(items, multiplier, 1)
            if multiplier == "quality":
                value_multi = DATA["quality"][items.quality]["multiplier"]
        
    if category == "percent" and _type != "bonus":
        value /= 100
    
    value = round(value * value_multi, 2)

    return {"value": value, "name": stats.get("name", None), "type": stats.get("type", None)}


def multiplerStats(items, player, stats):
    listv = []
    if isinstance(stats, list):
        for stat in stats:
            listv.append(_solved_multiplerStats(items, player, stat))
    if isinstance(stats, dict):
        listv.append(_solved_multiplerStats(items, player, stats))
    
    return listv
