from .. import entity, setup as init


class Enemy(entity.Entity):
    def __init__(self, name, _class, level):
        if _class not in init.DATA_ENTITY["attribute"]["player.role"]:
            return
        super().__init__(name, **init.DATA_ENTITY["class"][_class]["statsistic"])
       
        self.__class = _class
       
        self.exp = 0
        self.max_exp = 100
        self.level = level
        self.health = self.max_health
        self.mana = self.max_mana
        self.stamina = self.max_stamina

    
    @property
    def class_(self): return self.__class
