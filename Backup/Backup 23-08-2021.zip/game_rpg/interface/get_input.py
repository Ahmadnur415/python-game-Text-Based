from .. import setup
from .print_methode import print_


def get_input(add_text=""):
    return input(
        add_text + setup.SETTING["input_prompt"]
    ).strip().lower()


def get_enter(text: ""):
    input()

def get_boolean_input():
    while True:
        received_input = get_input()

        if received_input in setup.MESSAGES("input_messages.forms_of_true"):
            return True

        if received_input in setup.MESSAGES("input_messages.forms_of_false"):
            return False

        print_(setup.MESSAGES("input_messages.get_boolean_input"))