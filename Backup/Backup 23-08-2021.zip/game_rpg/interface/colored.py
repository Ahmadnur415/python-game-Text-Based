from .. import setup
import os

COLORS = dict(list(zip(['grey', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'], list(range(30, 38)))))
RESET = '\033[0m'

# make color game
os.system("color")

def colored(text, color=None):
    """Colorize text.

    Available text colors:
        red, green, yellow, blue, magenta, cyan, white.

    Example:
        colored('Hello, World!', 'green')
    """

    if color not in ("default", None, "") and setup.SETTING["color"]:
        if os.getenv('ANSI_COLORS_DISABLED') is None:
            fmt_str = '\033[%dm%s'
            text = fmt_str % (COLORS[color], text)
            text += RESET

    return text


def colored_items(text, quality):
    color = {"common": "grey", "uncommon": "green", "rare": "blue", "epic": "magenta", "legendary": "yellow", "special": "red"}
    return colored(text, color.get(quality, "white"))
 