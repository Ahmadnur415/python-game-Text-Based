import textwrap
from .. import setup

def printData(data: dict = None, one_line=False, mark=True, distance=8, **kwargs):
    if data is None:
        data = {}
    data.update(kwargs)
    k, v = [], []
    d = " " * distance

    if mark:
        line_1 = "{:<9}{mark} {:<12}"
        line_2 = "{:<9}{mark} {:<12}{:<9}{mark} {}"
    else:
        line_1 = "{}{} {}"
        line_2 = "{}{mark} {:<18}{}{mark} {}"

    mark = ":" if mark else ""
    

    for name_key, value in data.items():
        name_key = name_key.replace("_", " ")
        if one_line:
            print(d + line_1.format(name_key,  mark, value))
        else:
            k.append(name_key)
            v.append(value)
            if len(k) == len(v) == 2:
                print(d + line_2.format(k[0], v[0], k[1], v[1], mark=mark))
                k, v = [], []

    if len(k) == len(v) == 1:
        # print(k, v)
        print(d + line_1.format(k[0], v[0], mark=mark))

def list_line(line: list, number=False, pemisah=", ", replace: tuple=None):
    """
    argument:
        line: list
            ["1", 2, "b", True, 1.2]
        number: bool
            True and False
        pemisah: str
        replace: tuple
            ("_", " ")

    """

    text = ""
    for i, txt in enumerate(line):

        if replace and len(replace) == 2 and isinstance(txt, str):
            txt = txt.replace(replace[0], replace[1])

        if (i+1) == len(line):
            #text += " or "
            pemisah = ""
        if number:
            text += f"[{i+1}]"
        text += f"{txt}{pemisah}"

    return text


def dict_line(data: dict, short_text: bool = True,  **kwargs):
    line = ""
    data.update(kwargs)
    koma = ","
    for i, key in enumerate(data):
        if (i + 1) == len(data) and len(data) > 1:
            line += "and "
            koma = ""
        value = data[key]

        if key in setup.DATA_GAME["_view"] and short_text:
            key = setup.DATA_GAME["_view"][key]

        line += f"{key} {value}{koma} "
    return line



def print_(text, *args):
    text = list(args) + [text]
    for txt in text:
        WrapString = textwrap.wrap(txt, width=50)
        for line in WrapString:
            print(line)

def centerprint(text, *args):
    text = list(args) + [text]
    for txt in text:
        WrapString = textwrap.wrap(txt, width=50)
        for line in WrapString:
            print(f"{line:^50}")


def leftprint(text: str, distance: int=1, *args):

    f_txt = (" "*distance) + "{}"
    text = list(args) + [text]
    for txt in text:
        WrapString = textwrap.wrap(txt, width=50-distance)
        for line in WrapString:
            print(f_txt.format(line))


def line(d_left: int=None, d_rigth: int=None):
    t = "="
    if d_left and d_rigth:
        length = 50 - (d_left + d_rigth) 
        centerprint(t*length)
    elif d_left:
        length = 50 - d_left
        leftprint(t*length, distance=d_left)
    else:
        centerprint(t*50)

def LeftRigthPrint(left: str, rigth: str, distance: int=1):
    d = " " * distance
    start = d + left
    mid = "{:>" + str(50 - len(start) - len(d)) + "}" + d 
    end = mid.format(rigth)
    print(start + end)




if __name__ == '__main__':
    printData()
