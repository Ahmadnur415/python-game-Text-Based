from .. import interface
from ..items import EQUIPPABLE, CONSUMABLE


USE_ITEMS = "use Items"
CONSUME_ITEMS = "consume items"
REMOVE_ITEMS = "unequip items"
DISCARD_ITEMS = "discard items"
SELL_ITEMS = "sell items"
BACK = "back"
INVENTORY = "inventory"


def view_inventory_interface(player):
    while True:
        print()
        player.view_inventory()

        if not player.inventory:
            return BACK

        interface.leftprint(
            interface.get_messages("input_messages.choose_items_interface").format(
                name="Items",
                index="1" if len(player.inventory) == 1 else f"1 - {len(player.inventory)}"
            ), distance=0
        )
        index = interface.get_input()
        print()
        if index.lower() == "b":
            return BACK

        if index in [str(i) for i in range(1, len(player.inventory) + 1)]:
            index = int(index) - 1

            items = player.inventory[index]
            result = player.items_interface(items)
            if result == BACK:
                break


def items_interface(player, items):

    command = [USE_ITEMS if isinstance(items.attribute, CONSUMABLE) or isinstance(items.attribute, EQUIPPABLE) and not items.attribute.use else REMOVE_ITEMS]
    command.extend([SELL_ITEMS, DISCARD_ITEMS])
    print()
    items.view_stats()
    interface.centerprint("-")
    index = interface.get_command(command, True)
    print()

    if index in [USE_ITEMS, CONSUME_ITEMS]:
        result = "back"
        if isinstance(items.attribute, CONSUMABLE):
            result = player.consume_items(items)
        if isinstance(items.attribute, EQUIPPABLE):
            result = player.equip_items(items)

        if result == BACK:
            return result

        return player.items_interface(items)

    if index == REMOVE_ITEMS and isinstance(items.attribute, EQUIPPABLE):
        for locate_equip, items_equip in player.equipment.items():
            if items_equip == items:
                player.unequip_items(locate_equip)
                break
        else:
            print("items tidak ada di equipment")
            items.attribute.use = False
        return 

    if index == DISCARD_ITEMS:
        return

    if index == SELL_ITEMS:
        return

    if index == INVENTORY:
        return index


def use_items_consumable_interface(player, show_messages=True):
    while True:
        player.view_inventory("CONSUMABLE")

        if not player.consumable_items:
            break

        num = "1" if len(player.consumable_items) == 1 else f"1 - {len(player.consumable_items)}"

        interface.leftprint(
            interface.get_messages("input_messages.choose_items_interface").format(
                name="Items",
                index=num
            )
        )

        index = interface.get_input()
        print()

        if index.lower() == "b":
            return

        if index in [str(i) for i in range(1, len(player.consumable_items) + 1)]:
            index = int(index) - 1
        else:
            interface.print_(
                interface.get_messages("input_messages.get_enter") + " " + num + " or B\n"
            )
            print()
            continue

        items_to_use = player.consumable_items[index]

        player.consume_items(items_to_use, show_messages)


def view_stats_interface(player):
    commands = ["view attack"]

    interface.centerprint("-- STATS PLAYER --")
    player.view_stats()

    _input = interface.get_command(commands, True)
    print()
    if _input == "view attack":
        return view_attack_interface(player)

    if _input == BACK:
        return BACK


def view_attack_interface(player):
    commands = ["view stats"]
    interface.centerprint("-- ATTACK PLAYER --")
    player.view_attack()
    _input = interface.get_command(commands, True)

    if _input == BACK:
        return BACK
    
    if _input == "view stats":
        return player.view_stats_interface()
