from .. import interface
import math

def levelUp(self):
    count = 0
    while self.level < 60 and self.exp > self.max_exp:
        self.exp -= self.max_exp
        self.level += 1
        self.point_level += 3
        count += 1

    print()
    interface.centerprint(interface.get_messages("player.level_up").format(level=count))
    interface.get_enter()


def _generate_value_exp():

    @property
    def value_exp(player):
        return getattr(player, "_exp")
    
    @value_exp.setter
    def value_exp(player, value):
        max_exp = getattr(player, "max_exp")

        if value < 0:
            value = 0
        setattr(player, "_exp", value)
        
        if getattr(player, "exp") > max_exp:
            player.levelUp()

    return value_exp
