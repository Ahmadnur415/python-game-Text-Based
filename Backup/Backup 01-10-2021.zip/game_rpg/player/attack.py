from .. import interface


def view_attack(self):
    new_line = "\n" + " " * 3 + " ~ "
    for i, attack in enumerate(self.attack):
        line = " " + str(i + 1) + " : " + attack.displayName
        if attack.cost.stamina > 0:
            line += new_line + interface.get_messages("attack.stamina_cost_template").format(cost=attack.cost.stamina)
        if attack.cost.mana > 0:
            line += new_line + interface.get_messages("attack.mana_cost_template").format(cost=attack.cost.mana)

        print(line)


@property
def attack_name(self):
    return [attack.name for attack in self.attack]


def get_attack_from_name(self, name: str):
    for attack in self.attack:
        if attack.name == name:
            return attack



# # TODO: tidak digunakan
# def damage_of_attack_use(player, enemy, attack_use):
#     damage = attack_use.base_damage
#     row_damage = [0, 0]
#     for multiplier in attack_use.multiplier:
#         values = multiplier.stats if isinstance(multiplier.stats, (int, float)) else 1
#         if isinstance(multiplier.stats, str):
#             entity = multiplier.stats.split(".")[0].lower()
#             stats = multiplier.stats.split(".")[-1]
#             values = getattr(
#                 player if entity == "self" else enemy,
#                 stats,
#                 0
#             )
#         if isinstance(values, dict):
#             values = values[attack_use.typeAttack]
#         if isinstance(values, list):
#             values = 0
#             row_damage = [a + b for a, b in zip(values, row_damage)]
            
#         damage += round(multiplier.modifier * values)

#     return damage


# # TODO: tidak digunakan
# def _generate_damage_of_attack_use(player, enemy, attack_use):

#     damage = [1, attack_use.base_damage] if isinstance(attack_use.base_damage, (int, float)) else attack_use.base_damage
#     for multiplier in attack_use.multiplier:
#         if isinstance(multiplier.stats, (int, float)):
#             damage = [a + int(multiplier.stats * multiplier.modifier) for a in damage]
#             continue

#         values = 0
#         if isinstance(multiplier.stats, str):
#             entity = multiplier.stats.split(".")[0].lower()
#             stats = multiplier.stats.split(".")[-1]
#             values = getattr(
#                 player if entity == "self" else enemy,
#                 stats,
#                 0
#             )
#         if isinstance(values, dict):
#             values = values[attack_use.typeAttack]

#         if isinstance(values, list):
#             damage = [a + int(b * multiplier.modifier) for a, b in zip(damage, values)]
#             continue

#         if isinstance(values, (int, float)):
#             damage = [a + int(values * multiplier.modifier) for a in damage]
#             continue

#     return sorted(damage)