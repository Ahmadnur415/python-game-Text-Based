from ..items import CONSUMABLE
from .. import interface, setup


def consume_items(self, items_to_consume, show_messages=True):
    view = setup.GAME['_view'].copy()

    if not isinstance(items_to_consume.attribute, CONSUMABLE):
        print("Items ini tidak bisa dikonsumsi")
        return 

    consume = {}
    for stats, values in items_to_consume.attribute.stats.items():
        if isinstance(values, dict):
            values["modiefer"] = getattr(self, values["modiefer"])
            values = int(values["value"] / 100 * values["modiefer"])
        consume[stats] = values

    full = True
    names = []
    for name in consume.keys():
        if getattr(self, name) == getattr(self, "max_" + name, 0):
            names.append(name)
            full &= True
        else:
            full &= False

    if full and items_to_consume.attribute.type_ == "restore":
        interface.centerprint(interface.get_messages("player.messages.can_not_consumed_items").format(
            stats=interface.generate_readable_list(names), name=items_to_consume.name))
        print()
        return

    for stats, values in consume.items():
        prior_values = getattr(self, stats)
        setattr(
            self,
            stats,
            prior_values + values
        )

        if show_messages:
            if items_to_consume.attribute.type_ == "restore" and prior_values - getattr(self, stats, 0):
                interface.centerprint(
                    interface.get_messages("player.messages.item_consumed_restored").format(amount=values, value=stats)
                )
            elif items_to_consume.attribute.type_ == "increase":
                interface.centerprint(
                    interface.get_messages("player.messages.item_used_increased").format(stat=view.get(stats, stats),
                                                                                         amount=values)
                )

    items_to_consume.amount -= 1
    if items_to_consume.amount < 1 and items_to_consume in self.inventory:
        self.inventory.remove(items_to_consume)
        return "back"

    print()
    return 
