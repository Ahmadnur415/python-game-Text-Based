class Skill:
    def __init__(self):
        self.level = 1
        self.name = ""  # name = identify
        self.displayName = 0
        self.type_attack = 0
        self.base_damage = 0
        self.description_of_being_used=""
        self.cost_mp = 0
        self.cost_st = 0
        self.effect = 0
        self.multiplier = []

class Multiplier:
    def __init__(self, modifier, stats):
        self.modifier = modifier
        self.stats = stats

class _attackstyle:
    def __init__(self):
        self.damage_stats = ""