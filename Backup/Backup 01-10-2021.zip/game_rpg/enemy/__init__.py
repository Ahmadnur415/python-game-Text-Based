from .. import entity
from ..player import inventory, view, attack
from .level import _generate_stats_enemy


class Enemy(entity.Entity):
    def __init__(
        self, 
        name, 
        _class, 
        level,
        attacks,
        equipments,
        stats,
    ):
        super().__init__(
            name=name,
            namespace="Enemy", 
            _class=_class, 
            attacks=attacks, 
            equipments=equipments,
            stats=stats['stats'],
            type_attack=stats["typeAttack"],
            style_attack=stats["styleAttack"]
        )

        _generate_stats_enemy(self, stats.get("prority", []))
        self.level = level
        
        self.health = self.max_health
        self.mana = self.max_mana
        self.stamina = self.max_stamina

    append_inventory = inventory.append_inventory
    view_equipment = view.view_equipment

    view_attack = attack.view_attack
    get_attack_from_name = attack.get_attack_from_name
    attack_name = attack.attack_name
