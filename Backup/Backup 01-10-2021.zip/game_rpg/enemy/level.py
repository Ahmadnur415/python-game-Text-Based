from ..setup import DATA_ENTITY
from .. import until
import random


def _generate_stats_enemy(enemy, priority_stats):
    change_data = create_change_data_stats(priority_stats)
    for i in range(1, enemy.level+1):
        for j in range(0, 3):
            stats = until.resolve_random_condition(change_data)
            if not stats:
                stats = random.choice(DATA_ENTITY["stats"])
            value = getattr(enemy, stats, 0)
            
            # print(value, stats)
            if stats in DATA_ENTITY["entity_values"]["resource"]:
                setattr(enemy, stats, value + 3)
            else:
                setattr(enemy, stats, value + 1)


def create_change_data_stats(prority_stats: list):
    change_data = []

    priority_change = round(50 / len(prority_stats), 2)

    non_priority_stats = DATA_ENTITY["stats"].copy()
    [non_priority_stats.remove(i) for i in prority_stats]
    non_priority_change = round(50 / len(non_priority_stats), 2)

    count = 100
    for stats in DATA_ENTITY["stats"]:        
        if stats in prority_stats:
            count -= priority_change
            change_data.append((stats, priority_change))
        else:
            count -= non_priority_change
            change_data.append((stats, non_priority_change))

    return change_data