from .. import interface, setup


def view_stats(items):
    interface.centerprint(" === " + items.name + " === ")
    base_stats = {
        "quality": items.quality.capitalize(), "price": str(items.price["value"]) + " " + items.price["type"].capitalize(),
        "type": items.typeItems.capitalize()
    }

    if items.attribute.namespace == "EQUIPPABLE":
        base_stats.update({"using": items.attribute.use})
        interface.printData(base_stats, distance=1)
        view_EQUIPPABLE(items)
    if items.attribute.namespace == "CONSUMABLE":
        base_stats.update({"amount": items.amount})
        interface.printData(base_stats, distance=1)
        view_CONSUMABLE(items)


def view_EQUIPPABLE(items):
    _view = setup.GAME["_view"].copy()

    distance = 1

    if items.typeItems == 'weapons':
        damage_items = getattr(items.attribute, "damage", [0, 0])
        DMG = (" ~ ".join([str(i) for i in damage_items]) if isinstance(damage_items, list) else str(damage_items)) + " Damage"
        APEN = str(getattr(items.attribute, "armor_penetration", 0)) + "% armor penetration "
        interface.leftprint("weapons attribute (" + DMG + ", " + APEN + ")", distance=distance)

    for name in setup.DATA_ITEMS["attribute"]["basic"]:
        if name not in ("damage", "armor_penetration"):
            value = getattr(items.attribute, name, 0)
            if value != 0:
                interface.printData({_view.get(name, name): f"{value:+}"}, one_line=True, mark=False, distance=distance)

    for names, value in items.sub_stats.items():
        interface.printData({_view.get(names, names): f"{value:+}"}, one_line=True, mark=False, distance=distance)


def view_CONSUMABLE(items):
    ...
