import os
import json
from game_rpg.file import item, lang



def _load(filename):
    data = json.load(
        open(
            os.path.dirname(
                os.path.realpath(__file__)
            ) + "\\" + filename
        )
    )
    return data


def _init():
    core = _load("game.data.json")
    for name, path in core["fileGame"].items():
        data = None
        if name == "items":
            data = _load_items(path)
        elif name == "lang":
            data = _load_lang(path)
        elif name == "entity":
            data = _entity_data(path)
        else:
            data = _load(path)

        core[name] = data

    return core


def _load_items(path: str):
    items = _load(path)
    items["items"] = {}
    items["all_items"] = []
    for item_path in item.items:
        data_item = _load(items["path"] + item_path)
        items["items"][data_item["name"]] = data_item

        for items_in_data in data_item["items"].keys():
            items["all_items"].append(data_item["name"] + ":"+items_in_data)

    return items


def _load_lang(path):
    LANG = {}
    for lang_path in lang.path:
        data_lang = _load(path + lang_path)
        LANG[data_lang["identify"]] = data_lang
    return LANG


def _entity_data(path):
    DATA = _load(path)

    list_of_stats: list = []
    for _, name in DATA["entity_values"].items():
        list_of_stats.extend(name)
    
    DATA["stats"] = list_of_stats
    DATA["all_stats"] = list_of_stats.copy() + ["_max_" + name for name in DATA["entity_values"]["resource"]]

    return DATA 

if __name__ == '__main__':
    Game = json.dumps(_init(), indent=4)
    print(Game)
