items = [
  "armor.armor.json",
  "axe.weapons.json",
  "food.food.json",
  "m_f.food.json",
  "potion.potions.json",
  "bow.weapons.json",
  "staff.weapons.json",
]