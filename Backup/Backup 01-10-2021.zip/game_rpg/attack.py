from . import until
from .setup import _ATTACK


class _AttackStyle(object):
    def __init__(self, damage_stat):
        self.damage_stat = damage_stat


class COST(object):
    def __init__(self, mana, stamina):
        self.mana = mana
        self.stamina = stamina


class MULTIPLIER(object):
    def __init__(self, modifier, stats):
        self.modifier = modifier
        self.stats = stats


class Attack:
    def __init__(
            self,
            name,
            displayName,
            typeAttack,
            base_damage,
            multiplier=None,
            description_of_being_used="",
            cost=None
    ):
        if not isinstance(cost, COST):
            cost = COST(mana=0, stamina=0)
        if typeAttack not in ("magic", "physical"):
            typeAttack = "physical"
        if not isinstance(multiplier, list):
            multiplier = []

        until.set_multiple_attributes(
            self,
            name=name,
            displayName=displayName,
            typeAttack=typeAttack,
            base_damage=base_damage,
            multiplier=multiplier,
            description_of_being_used=description_of_being_used,
            cost=cost
        )


def ATTACK(data: dict):
    if not data or not isinstance(data, dict):
        return

    if not data.get("cost", None):
        data["cost"] = {"stamina": 0, "mana": 0}

    return Attack(
        name=data["name"],
        displayName=data["displayName"],
        typeAttack=data["typeAttack"],
        base_damage=data.get("base_damage", 0),
        multiplier=None if not data["multiplier"] else [
            MULTIPLIER(modifier=values["modifier"], stats=values["stats"])
            for values in data["multiplier"]
        ],
        description_of_being_used=data["description_of_being_used"],
        cost=COST(
            mana=data["cost"].get("mana", 0),
            stamina=data["cost"].get("stamina", 0)
        )
    )


ATTACK_STYLE = {
    name: _AttackStyle(damage_stat=stats) for name, stats in _ATTACK["style_attack"].items()
}


