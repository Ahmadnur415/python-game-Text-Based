import os
import pickle
from pathlib import Path
from datetime import datetime
from . import rooms, interface, create_player, items, setup


Path("./saves/").mkdir(parents=True, exist_ok=True)


class Game:
    def __init__(self):
        self.player = None
        self.version = [0, 0, 1]
        self.setting = None

    def new_game(self):
        self.player = create_player.create_player()
        self.player.append_inventory(items.get_items("armor:armor@1"))
        self.setting = setup.GAME["setting"].copy()


    def start(self):
        if not self.player:
            self.new_game()

        setup.SETTING = self.setting
        print(id(setup.SETTING), id(self.setting))
        return self.run()

    def run(self):
        if not self.player:
            return self.start()
        
        result = self.main_menu.name
        while True:
            if result in (self.main_menu.name, "main"):
                result = self.main_menu.enter(self)
                continue

            if result == self.adventure.name:
                result = self.adventure.enter(self)
                continue

            if result == self.camp.name:
                result = self.camp.enter(self)
                continue

            if result == "exit":
                return quit()
    
    def save_game(self):
        path = "./saves/"
        if not self.setting["savename"]:
            print('Over -DEBUG: game.py')
            name = self.player.name.replace(" ", "_") + ".sv"
            i = 0
            while name in os.listdir(path):
                name = self.player.name.replace(" ", "_") + f"_({i}).sv"
                i += 1
            self.setting["savename"] = name

        with open(path + self.setting["savename"], "wb") as f:
            pickle.dump(self, f, -1)

    def load_game(self):
        ...


    main_menu = rooms.main_menu
    camp = rooms.camp
    adventure = rooms.adventure
    

def load_game():
    loads = []
    listSave = os.listdir("./saves/")
    # title
    interface.centerprint("== Load Game ==")
    print(interface.get_messages("inventory.items_line").format(no="no", name="Name Player", quality="Level", type_="Time"))
    # Tidak ada save game
    
    if not listSave:
        interface.centerprint(interface.get_messages("game.no_file_save"))
        interface.get_enter()
        return "back"

    for i, filename in enumerate(listSave):
        game = pickle.load(open("./saves/" + filename, "rb"))
        time_save = datetime.fromtimestamp(os.path.getmtime("./saves/" + filename)).strftime("%X %x")
        loads.append(game)
        print(
            interface.get_messages("inventory.items_line").format(
                no=i+1, name=game.player.name, quality=game.player.level, type_=time_save
            )
        )
    result_index = interface.get_command(loads, False)
    return result_index
