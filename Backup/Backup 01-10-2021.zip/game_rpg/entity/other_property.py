from ..items import Items as ITEMS
from ..setup import DATA_ENTITY
from ..until import clamp
import math

# CON = 0
# STR = 0
# ARC = 0
# PERC = 0
# MGC = 0
# WILL = 0
# LUCK = 0
# LV = 0
# G_HP = 0
# G_MP = 0
# DEF = 0
# EVE = 0
# RES = 0


def init(entity):
    global CON, STR, ARC, PERC, MGC, WILL, LUCK, WILL, LUCK, LV, G_HP, G_MP, DEF, EVE, RES
    CON = getattr(entity, "constitution", 0)
    STR = getattr(entity, "strength", 0)

    ARC = getattr(entity, "archery", 0)
    PERC = getattr(entity, "perception", 0)

    MGC = getattr(entity, "magic", 0)
    WILL = getattr(entity, "will", 0)

    LUCK = getattr(entity, "luck", 0)
    LV = getattr(entity, "level", 1)
    G_HP = getattr(entity, "growth_hp", 0)
    G_MP = getattr(entity, "growth_mp", 0)

    DEF = getattr(entity, "defense", 0)
    EVE = getattr(entity, "evasion", 0)
    RES = getattr(entity, "resistance", 0)


# ===========
# Reduce
# ===========
def physical_reduce(entity):
    # point defense -> Random
    # init
    init(entity)

    bonus_dr = 0
    for items in entity.equipment.values():
        if items:
            bonus_dr += items.attribute.defense

    total_dr = math.floor((DEF + bonus_dr + clamp(CON / 4, 1, 100) + clamp(RES / 10, 1, 100)) / 4)
    return clamp(math.floor(100 - 10000 / (100 + total_dr)), 1, 95)


def magic_reduce(entity):
    init(entity)

    bonus_mr = 0
    for items in entity.equipment.values():
        if items:
            value = items.sub_stats.get("resistance", None)
            if value:
                bonus_mr += value

    total_mr = math.floor((RES + bonus_mr + clamp(MGC / 7, 1, 100) + clamp(WILL / 8, 1, 100)) / 4)
    return clamp(math.floor(100 - 10000 / (100 + total_mr)), 1, 95)


@property
def reduce_damage(entity) -> dict:
    return {"physical": physical_reduce(entity), "magic": magic_reduce(entity)}


# NOTE ==================== WIP ====================
@property
def evaded(entity):
    init(entity)

    bonus = 0
    for items in entity.equipment.values():
        if items:
            bonus += items.attribute.evasion

    return clamp(round((bonus + (EVE * 0.7) + int(LUCK / 120) + (PERC / 20)) * 0.8, 2), 1, 95)


# =========
# resaurce
# =========



@property
def max_health(entity):
    init(entity)
    HP = G_HP * ((CON * 70 + WILL * 5 + STR) / 21 + ((50 - (0.121 * LV)) * LV)) / 100
    return math.floor(HP + getattr(entity, "_max_health", 0))


@property
def max_mana(entity):
    init(entity)
    MP = G_MP * ((25 * WILL + 2 * MGC) / 10 + 5 * LV / 2) / 100
    return math.floor(MP + getattr(entity, "_max_mana", 0))


@property
def max_stamina(entity):
    init(entity)
    ST = (15 * ARC + 30 * PERC + 26 * STR + 125 * LV) / 60
    return math.floor(ST + getattr(entity, "_max_stamina", 0))


@property
def critical_change(entity):
    # init
    init(entity)

    bonus = 0
    # equipment bonus
    for items in entity.equipment.values():
        if isinstance(items, ITEMS):
            values = items.sub_stats.get("critical_change", {})
            bonus += values.get("value", 0)

    crit = (PERC / 4) + (STR * 2 + ARC + MGC) / 30 + (0.3 * LV) + clamp(LUCK / 200, 1.0, 25.0)
    return clamp(round(crit + bonus, 2), 1, 99)


@property
def critical_hit(entity):
    # init 
    init(entity)

    bonus = 0
    # equipment bonus
    for items in entity.equipment.values():
        if isinstance(items, ITEMS):
            bonus += items.sub_stats.get("critical_hit", 0)

    dmg = (4 * STR + 4 * ARC + 4 * MGC + 3 * PERC + 2 * LV + 2 * CON) / 5 + clamp(LUCK / 100, 1, 50)
    return round(dmg + 20 + bonus, 2)


# ==========
# damage
# ==========

@property
def damage(entity):
    init(entity)
    floor = math.floor

    physical = [
        floor((1.2 + 1.1 * LV) + (7 * STR + ARC) / 21),
        floor((1 + 1.2 * LV) + (STR + ARC * 7) / 10)
    ]
    magic = [
        floor((0.9 + 0.7 * LV) + (7 * MGC + WILL) / 9),
        floor((1 + 1.1 * LV) + (3 * MGC + WILL * 7) / 10),
    ]

    # print(physical, magic)

    for name in DATA_ENTITY["attribute"]["equipment"]["weapons"]:
        equipment = entity.equipment.get(name, None)
        if equipment:
            # get damage stats (ARC / MGC / STR)
            damage_stat = equipment.attribute.styleAttack.damage_stat

            # multiplier damage
            multiplier = 1
            if damage_stat == entity.style_attack:
                multiplier = getattr(entity, damage_stat, 0) / 6 + (CON / 20) + (LV * 0.3)

            # menambahkan damage 
            if damage_stat == "magic":
                magic = [a + int(b + b * multiplier) for a, b in zip(magic, equipment.attribute.damage)]
            else:
                physical = [a + int(b + b * multiplier) for a, b in zip(physical, equipment.attribute.damage)]

    return {"physical": sorted(physical), "magic": sorted(magic)}


@property
def magic_damage(entity):
    return entity.damage["magic"]


@property
def physical_damage(entity):
    return entity.damage["physical"]


@property
def max_exp(entity):
    init(entity)
    return math.floor((175 * LV + 50) / math.pi)
