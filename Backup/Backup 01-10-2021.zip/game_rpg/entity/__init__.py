from ..setup import DATA_ENTITY as DATA
from . import other_property, attack, entity_until, equipment, view


class Entity:
    def __init__(
            self,
            name: str = "Entity",
            namespace: str = "entity",
            _class=None,
            attacks: list = None,
            equipments: dict = None,
            stats: dict = None,
            type_attack=None,
            style_attack=None
    ):

        if not stats:
            stats = {}

        for names, value in stats.items():
            if names in DATA["entity_values"]["resource"]:
                names = "_max_" + names
            setattr(self, names, value)

        for stat in DATA["all_stats"]:
            if not hasattr(self, stat):
                setattr(self, stat, 0)

        if attacks is None:
            attacks = []

        if equipments is None:
            equipments = {}

        self.__name = name
        self.__namespace = namespace.lower()
        self.__class = _class
        self.level = 1
        self.equipment = dict.fromkeys(DATA["equipment"])
        self.inventory = []
        self.attack = attacks
        self.type_attack = type_attack
        self.style_attack = style_attack

        for locate, item_to_equip in equipments.items():
            self.equip_items(item_to_equip, locate)

    @property
    def name(self):
        return self.__name

    @property
    def _class(self):
        return self.__class

    @property
    def namespace(self):
        return self.__namespace

    # statsistic entity
    max_health = other_property.max_health
    max_mana = other_property.max_mana
    max_stamina = other_property.max_stamina

    #
    critical_change = other_property.critical_change
    critical_hit = other_property.critical_hit

    #
    reduce_damage = other_property.reduce_damage
    magic_damage = other_property.magic_damage
    physical_damage = other_property.physical_damage
    evaded = other_property.evaded
    damage = other_property.damage

    attack_state = attack.attack_state
    _generate_damage_of_attack_use = attack._generate_damage_of_attack_use
    usable_attacks = attack.usable_attacks

    equip_items = equipment.equip_items
    unequip_items = equipment.unequip_items

    view_stats = view.view_stats


# create health 
for name in DATA["entity_values"]["resource"]:
    setattr(
        Entity,
        name,
        entity_until._generate_value_property(name)
    )
