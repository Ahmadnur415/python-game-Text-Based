


def enter(self, game):
    ...