from .camp import ROOM as camp
from .main_menu import ROOM as main_menu
from .adventure import ROOM as adventure

main_menu.add_commands(
    adventure.name,
    camp.name
)
camp.add_commands(
    main_menu.name
)