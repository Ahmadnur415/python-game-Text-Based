from ..import enemies, battle, interface
from ..room import Room
import random


def enter(self, game):
    
    if game.player.health < game.player.max_health * 0.3:
        return "main"

    if not (self.enemy and isinstance(self.enemy, enemies.Enemy)):
        self.enemy = enemies.enemyRandom(
            enemies._generate_enemy_level(game.player.level, game.setting["difficulty"]))
    result_battle = battle.Battle(game.player, self.enemy).run()

    if result_battle == "lose":
        ...

    if result_battle == "win":
        loot = random.choice(self.loot_create)
        interface.centerprint("KAMU MENANG", f"KAMU DAPAT LOOT {loot}")
        interface.get_enter()
    
    self.enemy = None
    
    return "main"

ROOM = Room(
    "adventure",
    enter=enter,
    commands=None,
    enemy=None,
    loot_create=[
        "armor:armor@1"
    ]
)