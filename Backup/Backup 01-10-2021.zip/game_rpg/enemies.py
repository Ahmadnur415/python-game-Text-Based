from .enemy import Enemy
from .setup import _ENEMY, _ATTACK
from . import attack
import random


def _generate_enemy_level(lv: int, diff: int):
    if 3 < lv <= 7:
        lv = (1, lv)
    elif lv > 7:
        if lv < 58:
            max_lv = lv + diff
            if max_lv > 60:
                max_lv = 60
            lv = (lv - int(4  - (1.5 * diff)) , max_lv)
        elif lv >= 58:
            lv = (57 - int(4  - (1.5 * diff)), lv)

    return lv



def enemyRandom(lv=3):
    if isinstance(lv, (list, tuple)):
        lv = random.randint(min(lv), max(lv))

    _class = random.choice(_ENEMY["class_enemy"].copy())
    DATA = _ENEMY["class"][_class].copy()
    if _class in _ENEMY["variant"]:
        variant_enemy = random.choice(_ENEMY["variant"][_class].copy() + ["default"])
        if variant_enemy != "default":
            DATA["stats"].update(variant_enemy.get("stats", {}))
            variant_enemy.pop("stats", None)
            DATA.update(variant_enemy)
            
    return Enemy(
        name=DATA["name"],
        _class=_class,
        level=lv,
        attacks=[
            attack.ATTACK(
                _ATTACK.get("basic_attack", {}).copy()
            )
        ],
        equipments=None,
        stats=DATA
    )