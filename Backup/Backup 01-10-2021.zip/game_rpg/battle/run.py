def run(battle):

    while True:

        battle.run_turn()

        if battle.fled:
            return "fled"

        if battle.player.health <= 0:
            return  battle.LOSE

        if battle.enemy.health <= 0:
            return  battle.WIN
