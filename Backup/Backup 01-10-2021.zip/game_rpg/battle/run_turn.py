from .. import interface


def run_turn(battle):
    battle.view_battle()
    interface.centerprint("~")

    battle.run_player_turn()

    if battle.fled or battle.enemy.health <= 0:
        return

    battle.run_enemy_turn()

    print("\n")
