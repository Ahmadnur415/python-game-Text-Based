ATTACK = "attack"
USE_ITEMS = "use items"
FLED = "fled"
BACK = "back"
WIN = "win"
LOSE = "lose"
TURN_COMMANDS = [ATTACK, USE_ITEMS, FLED]


# def get_player_command_attack(battle):
#     commands = battle.player.view_attack.copy()
#     commands.append(BACK)
