__name__ = "debug"



# from game_rpg import create_player, items, enemies, battle
# player = create_player.create_player()
# enemy = enemies.enemyRandom()
# axe_weapons = items._generate_items("axe", 1)
# food = items._generate_items("food", 1)
# armor = items.get_items("armor:wood_armor@1")
# player.equip_items(axe_weapons, "main_hand")
# player.equip_items(armor)
#
# axe_weapons.view_stats()
# print(axe_weapons.__dict__)
# print(axe_weapons.attribute.__dict__)
# a = enemy.attack[0]
# print(a.multiplier[0].__dict__)

from game_rpg import play, create_player, items, enemies, battle, setup

if __name__ == "main":
    play.play()
else:
    player = create_player._create()
    staff_items = items.get_items("staff:fbi_staff")
    print(staff_items.attribute.attack[0].__dict__)


"""
--- Main Menu ---
1. ADVENTURE -> ROOM
2. CAMP --> ROOM
3. SHOP --> ROOM
4. SETTING --> ROOM
4. EXIT --> quit()

--- CAMP ---
1. view Player
2. Inventory
3. Equipment
4. save Game
5. MAIN MENU

-- SHOP --
1. WEAPONS
2. ARMOR
3. BLACK MARKET
4. MAIN MENU


"""