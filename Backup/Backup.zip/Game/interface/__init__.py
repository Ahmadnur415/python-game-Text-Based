from .get_input import get_input, get_enter, get_boolean_input
from .print_methode import printData

