"""from text_based_game.setup import init
from text_based_game.interface.get_border import border
import textwrap

length = init.setting["length_game"]

def print_format(text: list, f_char: str):
    width = length - 4
    text_format = "{} {:" + f_char + str(width)+"} {}"

    for key in text:
        WrapString = textwrap.wrap(key, width=width)
        for line in WrapString:
            print(text_format.format(border("side", 3), line, border("side", 3)))

def centerprint(text, *text2):
    if type(text) == list: text = text + list(text2)
    else: text = [text] + list(text2)
    print_format(text, "^")

def leftprint(text, *text2):
    if type(text) == list: text = text + list(text2)
    else: text = [text] + list(text2)
    print_format(text, "<")

def rightprint(text, *text2):
    if type(text) == list: text = text + list(text2)
    else: text = [text] + list(text2)
    print_format(text, ">")

def line(position: str, num: int = 1):
    width = length - 2
    if position.lower() == "top":
        print(border("left", 1) + (border("side", 1) * width) + border("right", 1))
    if position.lower() == "mid" and 2 >= num >= 1:
        print(border("left", num + 1) + (border("side", num) * width) + border("right", num + 1))
    if position.lower() == "end":
        print(border("left", 4) + (border("side", 1) * width) + border("right", 4))

def print_multi_stats(**stats):
    for key, value in stats.items():
        lr_stat(key, value)

def print_list_on_line(data: list, space: str = " "):
    text = ""
    for i in range(0, len(data)):
        if len(data) == 1 or (len(data) - 1) == i:
            text += str(data[i])
        else:
            text += str(data[i]) + space
    return text

def lr_print(header, body):
    lr_header(header)
    leftprint(body)
    line("end")

def lr_header(text):
    line("top")
    centerprint(text)
    line("mid", 1)


def lr_stat(key, value):
    value = str(value)
    key = key.replace("_", " ")
    start = "{} {:<15} : {}".format(border('side', 3), key, value)
    end = "{} {}".format(" " * ((length - 2) - len(start)), border('side', 3))
    text = start + end

    WrapString = textwrap.wrap(text, width=length)
    for line in WrapString:
        print('{}'.format(line))

def lr_data(num, key, value):
    # print("="*50)
    no = f"{border('side', 3)} {num}"
    # print(len(no))
    start = "{}{}".format(" " * (7 - len(no)), key)
    mid = "{}{}".format(" " * (length - 15 - len(start) - len(no)), value)
    end = "{}{}".format(" " * (length - 1 - (len(mid) + len(start) + len(no))), border('side', 3))
    print(no + start + mid + end)


def print_(text):
    line("top")
    centerprint(text)
    line("end")

def margin_print(text, line="mid", position="center"):
    if position == "center":
        f_char = "^"
    if position == "left":
        f_char = "<"
    if position == "right":
        f_char = ">"

    text_f = "{:" + border("side", 2) + f_char + str(length - 4) + "}"
    text = border("side", 2) + text_f.format("[ " + str(text) + " ]") + border("side", 2)

    if line == "top":
        print(border("left", 7) + text + border("right", 7))
    elif line == "end":
        print(border("left", 6)+ text + border("right", 6))
    else:
        print(border("left", 3)+ text + border("right", 3))


if __name__ == '__main__':
    centerprint("Hello world")
    leftprint("Hello world")
    rightprint("Hello world")
    print()

    # line
    line("top")
    line("mid")
    line("mid", 2)
    line("end")
    print()

    # print data
    print(print_list_on_line(data=["1", "2", "3", "4"], space="|"))
    print_multi_stats(hy="Hello world")
    lr_stat(key="key", value="value")
    lr_data(num="1", key="key", value="value")
    print()

    # ===
    lr_header("header")
    lr_print("header", "body")
    print_("normal print but using line top and end")

    # margin print
    margin_print(text="top-center", line="top", position="center")
    margin_print(text="top-left", line="top", position="left")
    margin_print(text="top-right", line="top", position="right")

    margin_print(text="mid-center", line="mid", position="center")
    margin_print(text="mid-left", line="mid", position="left")
    margin_print(text="mid-rigth", line="mid", position="right")

    margin_print(text="end-center", line="end", position="center")
    margin_print(text="end-left", line="end", position="left")
    margin_print(text="end-right", line="end", position="right")
"""