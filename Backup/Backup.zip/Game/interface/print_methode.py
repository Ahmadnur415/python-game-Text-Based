# import textwrap


def printData(data: dict = None, **Data1):
    if data is None:
        data = {}
    data.update(Data1)

    k, v = [], []
    text = "\t{:<9}: {:<12}{:<9}: {}"
    for name_key, value in data.items():
        k.append(name_key.replace("_", " "))
        v.append(value)
        if len(k) == len(v) == 2:
            print(text.format(k[0], v[0], k[1], v[1]))
            k, v = [], []

    if len(k) == len(v) == 1:
        print("\t{:<9}: {:<12}".format(k[0], v[0]))

if __name__ == '__main__':
    printData()
