


class Entity:
    def __init__(self, **stats):
        
        self.strength = 0
        self.magic = 0
        self.archery = 0
        self.constitution = 0
        self.will = 0
        self.perceprion = 0

        self.health = 0
        self.mana = 0
        self.stamina = 0
        
        self.growth_hp = 0
        self.growth_mp = 0
        self.luck = 0

        self.defense = 0
        self.evasion = 0
        self.resisitance = 0
        self.aPen = 0

        

        for value, key in stats.items():
            setattr(self, value, key)
        
    
    @property
    def max_health(self, bonus):
        ...
    
    @property
    def max_mana():
        ...

    @property
    def max_stamina():
        ...
    
    @property
    def critical_change():
        ...
    
    @property
    def critical_damage():
        ...