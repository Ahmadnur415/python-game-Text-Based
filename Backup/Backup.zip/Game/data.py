import json


def load_data(filename):
    folder = "./Data"

    data = json.loads(folder + filename + ".json")

    return data
