from .data import load_data


DATA_ITEMS = load_data("items.data")
