from .create import *
from . import generate
from ..setup import DATA_ITEMS


def get_items(_class, quality: int="common", index: int=1,  name: str=None, amount: int=1, att="basic", stats="basic"):
    if _class in DATA_ITEMS["list"]: 
        typeItems = DATA_ITEMS["list"][_class].split(".")[-1]
        if typeItems in ("food", "potions"):
            return generate.get_items_CONSUMABLE(baseItems=_class, name=name, amount=amount, index=index)
        if typeItems in ("armor", "weapons"):
            return generate.get_items_EQUIPPABLE(baseItems=_class, quality=quality, index=index,att=att, stast=stats)
    
    return print("warring[2]: {}")