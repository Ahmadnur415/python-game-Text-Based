from ..data import load_data as _load
from .. import until, setup
from . import create
import random


def get_items_EQUIPPABLE(baseItems, quality, index=1, att="basic", stast="basic"):
    """
    _type: type dari items tersebut dapat berupa armor, weapons
    baseItems: semacam axe, helmet
    quality: qualitas dari items
    index: menentukan pilihan dari items
    """
    
    try:
        DATAITEMS = _load("items\\" + setup.DATA_ITEMS["list"][baseItems])
    except FileNotFoundError as k:
        return print(k)

    type_items = DATAITEMS["type_items"]
    quality = quality if quality != "random" else random.choice(list(DATAITEMS["item"].keys()))    
    max_index = len(DATAITEMS["item"][quality])
    index = random.randint(0, max_index - 1) if index == "random" else index - 1

    if (index < 0) or (index >= max_index) or (quality not in DATAITEMS["item"]):
        return print("Warning[0]: tidak bisa mendapatkan items")

    items = DATAITEMS["item"][quality][index]                                   # mendapatkan items
    items["sub_stats"] = items.get("sub_stats", {})                             # basis data tidak ada substats maka akan secara otomatis membuat substats

    if att == "random":                                                         # random weapons attrinute
        if type_items == "weapons":
            d_dmg = items.get("damage", [5, 10])                                # default damage
            d_aPen = items.get("armor_penetration", random.randint(0, 25))      # dafault armor_penetration

            items["damage"] = sorted([until._generate_random_value(int(d_dmg[0] * 0.6)), until._generate_random_value(int(d_dmg[1] * 1.2))])
            items["armor_penetration"] = until._generate_random_value(int(d_aPen * 0.5))

        # random armor attribute
        if type_items == "armor":
            d_DEF = items.get("defense", 20)
            d_EVE = items.get("evesion", 20)
            items["defense"] = until._random_value_list([int(d_DEF * 0.6), int(d_DEF * 1.5)])
            items["evesion"] = until._random_value_list([int(d_EVE * 0.6), int(d_EVE * 1.5)])


    if stast == "random":
        sub_stats = setup.DATA_ITEMS["attribute"]["subs_stats"]
        d_st = items["sub_stats"]                                                               # d_st = default sub stats
        for i in range(random.randint(1, 4)):
            i_st = until._generate_random_value(len(sub_stats) - 1)                             # ist = index sub stats // random(1, max)
            get_st = sub_stats[i_st]                                                            # get sub stats 
            v_st = until._random_value_list(get_st["value"])                                    # get value form get_st["value"]: list
            while get_st["name"] in d_st:                                                       # loop bila terjadi kesamaan
                i_st = until._generate_random_value(len(sub_stats) - 1)
                get_st = sub_stats[i_st]
                v_st = until._random_value_list(get_st["value"])

            d_st[get_st["name"]] = v_st                                                         # memasukan value dan key ke dalam default sub stats

        items["sub_stats"] = d_st                                                               # memasukan dict ke dala items["sub_stats"]

    # return items
    return create.Items(
        name=items["name"],
        quality=quality,
        type_items=type_items,
        identify=items["id"],
        price=items["price"],
        attribute=create.EQUIPPABLE(
            location=DATAITEMS["slot"],
            user=DATAITEMS["user"],
            pasive=None,
            **{key: items.get(key, 0) for key in setup.DATA_ITEMS["attribute"][type_items]}           # DMG , A.pen and DEF, EVA
        ),
        sub_stats=create.SUBSTATS(**items["sub_stats"])
    )


def get_items_CONSUMABLE(baseItems, name=None, amount=1, index=0):
    try:
        # load items in list items 
        DATAITEMS = _load(
            "items\\" + setup.DATA_ITEMS["list"][baseItems]
        )
    except FileNotFoundError as k:
        return print(k)

    if index != "random" and type(index) == str:                        # cek index samadengan str dan buka "random"
        return print("Warning[0]: tidak bisa mendapatkan items")

    index = random.randint(0, len(DATAITEMS["list"]-1)) if index == "random" else index - 1

    if index < 0 or index >= len(DATAITEMS["list"]):                    # index out of range       
        return print("Warning[1]: tidak bisa mendapatkan items")

    if name not in DATAITEMS["item"] or not name:                       # get items menggunakan index dan nama tidak terdaftar di DATAITEMS["item"]
        index_items = DATAITEMS["list"][index]                          # index_items = list["item.apple", "item.potion"]   
        items = DATAITEMS["item"][index_items.split(".")[-1]]
    else:
        items = DATAITEMS["item"][name]                                 # get items using name
    
    return create.Items(
        name=items["name"],
        quality=items["quality"],
        type_items=DATAITEMS["type_items"],
        identify=items["id"],
        price=items["price"],
        amount=amount,
        attribute=create.CONSUMABLE(
            type_=items["type"],
            stats=items["stats"]
        )
    )
