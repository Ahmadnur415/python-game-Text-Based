from .. import data, entity, setup, until
from . import attribute, view_stats
import random


class Player(entity.Entity):
    def __init__(self, name="Player", role=random.choice(["archer", "mage", "assasins", "warrior"])):
        super().__init__()
        self.TYPE = "Player"
        
        self.__name = name
        self.__role = role

        self.__max_health = 0
        self.__max_mana = 0
        self.__max_stamina = 0

        until.set_multiple_attributes(self,level=1, max_exp=100, exp=0, silver=10000, gold=100)

        attribute.att_role(self)


    def __repr__(self):
        return f"Player({self.__name}, {self.__role})"

    @property
    def name(self):
        return self.__name

    @property
    def role(self):
        return self.__role

    @property
    def max_health(self):
        """HP = attribute.get_health(self) + a
        if self.health >= self.__max_health:
            self.health = HP
        self.__max_health = HP"""
        return super().max_health

    @property
    def max_mana(self):
        MP = attribute.get_mana(self)
        if self.mana >= self.__max_mana:
            self.mana = MP
        self.__max_mana = MP
        return self.__max_mana

    @property
    def max_stamina(self):
        ST = attribute.get_stamina(self)
        if self.stamina >= self.__max_stamina:
            self.stamina = ST
        self.__max_stamina = ST
        return self.__max_stamina

    @property
    def critical_change(self):
        return attribute.crit_change(self)

    @property
    def critical_hit(self):
        return attribute.crit_damage(self)

    @staticmethod
    def get_role(self):
        attribute.att_role(self)

    view = view_stats.view_stats

