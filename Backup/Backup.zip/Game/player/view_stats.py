from .. import interface


def view_stats(player):

    EXP_PER = round((100 * player.exp) / player.max_exp, 1)
    if player.level < 60:
        exp = str(player.exp) + "/" + str(player.max_exp) + " | " + str(EXP_PER) + "%"
    else:
        exp = "0 / 0 | 0% (max)"

    # Show
    print(f"{player.name} : ")

    # ========
    print('\t>>> Primal Stats')
    interface.printData({"STR": player.strength, "CON": player.constitution, "MAGIC": player.magic, "WILL": player.will,
                         "ARC": player.archery, "PERC": player.perception})

    # ========
    print("\t>>> Subs Stats")
    interface.printData({"Health": player.max_health, "Mana": player.max_mana, "Stamina": player.max_stamina,
                         "C.Change": str(player.critical_change) + "%", "C.Hit": player.critical_hit, "Luck": player.luck,
                         "Growth Hp": player.growth_hp, "Growth Mp": player.growth_mp})

    # ========
    print("\t>>> Defense")
    interface.printData({"DEF": player.defanse, "RES": player.resistance, "Evasion": player.evasion, "A.Pen": player.armor_penetration})

    # ========
    print("\t>>> Other")
    interface.printData(
        {"Gold": player.gold, "Silver": player.silver, "Level": player.level, "Exp": exp, "Role": player.role})
    