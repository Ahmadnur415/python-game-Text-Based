from .. import until, setup
import math


def init(player):
    global CON, STR, ARC, PERC, MGC, WILL, LUCK, WILL, LUCK, LV, G_HP, G_MP
    
    CON = player.constitution
    STR = player.strength

    ARC = player.archery
    PERC = player.perception

    MGC = player.magic
    WILL = player.will

    LUCK = player.luck
    LV = player.level
    G_HP = player.growth_hp
    G_MP = player.growth_mp


def get_health(player):
    init(player)

    HP = G_HP * ((CON * 70 + WILL * 5 + STR) / 21 + ((50 - (0.121 * LV)) * LV)) / 100

    return math.floor(HP + 50)


def get_mana(player):
    init(player)

    MP = G_MP * ((25 * WILL + 2 * MGC) / 10 + 5 * LV / 2) / 100

    return math.floor(MP + 20)


def get_stamina(player):
    init(player)

    MP = (15 * ARC + 30 * PERC + 26 * STR + 125 * LV) / 60
    return math.floor(MP + 12)


def crit_change(player):
    init(player)

    crit = LUCK * ((PERC / 4) + (STR * 2 + ARC + MGC) / 30 + (0.3 * LV)) / 120
    return round(crit, 2)

def crit_damage(player):
    init(player)

    dmg = (4 * STR + 4 * ARC + 4 * MGC + 3 * PERC + 2 * LV + 2 * CON) / 5
    return round(dmg + 20, 2)


def att_role(entity):
    datarole = setup.DATA_PLAYER["role"] if entity.TYPE == "player" else setup.DATA_PLAYER["role"]
    if entity.role in datarole:
        until.set_multiple_attributes(entity, **datarole[entity.role.lower()])