from .setup import DATA_ENTITY


class Entity:
    def __init__(self):

        data_stats = DATA_ENTITY["stats"]
        for stats in data_stats["primary"]:
            setattr(self, stats, 0)

            # other stats / resource
        for stats in data_stats["other"]["resource"]:
            setattr(self, stats, 0)

            # other stats / secondary
        for stats in data_stats["other"]["secondary"]:
            setattr(self, stats, 0)

            # other stats / defense
        for stats in data_stats["other"]["defense"]:
            setattr(self, stats, 0)
    

    @property
    def max_health(self):
        return 10000