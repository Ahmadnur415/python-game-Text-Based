"""from Game import player, setup, items, enemy

hero = player.Player("Hero")
# setup.init.player = hero
# hero.level = 5
# golem = enemy.Enemy("Golem")


armor = items.get_items(_class="armor", quality="special", index=1)
weapons = items.get_items(_class="axe", quality="common", index=2, stats="random", att="random")
potion = items.get_items(_class="potions", name="recover_potion", index=1) 
food = items.get_items(_class="food", name="apple")
mod_food = items.get_items(_class="mod_food", index=1)
 """



if __name__ == '__main__':
    ...
    